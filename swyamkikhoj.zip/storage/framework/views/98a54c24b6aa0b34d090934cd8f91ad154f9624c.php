<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="main-banner header-text">
        <div class="container-fluid">
            <div class="owl-banner owl-carousel">
                <?php $__empty_1 = true; $__currentLoopData = $bannerPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannerPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="item">
                        <img src="<?php echo e(asset('/postBanner/'.$bannerPost->banner->banner_image)); ?>" alt="">
                        <div class="item-content">
                            <div class="main-content">
                                <div class="meta-category">
                                    <span><?php echo e($bannerPost->category->name); ?></span>
                                </div>

                                <a href="<?php echo e(route('guest.post', $bannerPost->slug)); ?>"><h4><?php echo e($bannerPost->title); ?></h4></a>

                                <ul class="post-info">
                                    <li><?php echo e(\Carbon\Carbon::parse($bannerPost->created_at)->format('M d, Y')); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <section class="blog-posts">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="all-blog-posts">
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-lg-12">
                                    <div class="blog-post">
                                        <div class="blog-thumb">
                                         
                                            <img src="<?php echo e(asset('/postBanner/'.$post->banner->banner_image)); ?>" alt="<?php echo e(asset('/postBanner/'.$post->banner->banner_image)); ?>">
                                        </div>

                                        <div class="down-content">
                                            <span><?php echo e($post->category->name); ?></span>
                                            <a href="<?php echo e(route('guest.post', $post->slug)); ?>"><h4><?php echo e($post->title); ?></h4></a>
                                            <ul class="post-info">
                                                <li><a href="javascript:void(0)"><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('M d, Y')); ?></a></li>
                                            </ul>

                                            <div class="post-content">
                                                <p>
                                                    <?php echo $post->content; ?>

                                                </p>
                                            </div>

                                            <p>
                                                <a href="<?php echo e(route('guest.post', $post->slug)); ?>">(Read More)</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>

                            <?php if(count($posts) > 0): ?>
                                <div class="col-lg-12">
                                    <div class="main-button">
                                        <a href="blog.html">View All Posts</a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="sidebar">
                        <div class="row">
                            
                            <?php echo $__env->make('guest.partials.recent-posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('guest.partials.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\swyamkikhoj\resources\views/guest/home.blade.php ENDPATH**/ ?>