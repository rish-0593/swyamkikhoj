<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Swayam Ki Khoj')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

        <link href="<?php echo e(asset('assets/frontend/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/assets/css/fontawesome.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/assets/css/templatemo-stand-blog.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/assets/css/owl.css')); ?>">
        <style>
            .blog-posts .down-content p {
                padding: unset !important;
                margin: 25px 0px !important;
                border-top: unset !important;
                border-bottom: unset !important;
            }

            .post-content {
                display: -webkit-box;
                -webkit-line-clamp: 5;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }
        </style>

        <?php echo e($styles ?? ''); ?>

    </head>
    <body>
        <?php echo $__env->make('guest.partials.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('guest.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo e($slot); ?>


        <?php echo $__env->make('guest.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script src="<?php echo e(asset('assets/frontend/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/assets/js/custom.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/assets/js/owl.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/assets/js/slick.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/assets/js/isotope.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/frontend/assets/js/accordions.js')); ?>"></script>

        <?php echo e($scripts ?? ''); ?>

    </body>
</html>
<?php /**PATH C:\laragon\www\swyamkikhoj\resources\views/layouts/guest.blade.php ENDPATH**/ ?>