<div id="preloader">
    <div class="jumper">
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<?php /**PATH C:\laragon\www\swyamkikhoj\resources\views/guest/partials/preloader.blade.php ENDPATH**/ ?>